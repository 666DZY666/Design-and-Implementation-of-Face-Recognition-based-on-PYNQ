The provided networks have been found here:

AlexNet: https://github.com/BVLC/caffe/tree/master/models/bvlc_alexnet
GoogLeNet: https://github.com/BVLC/caffe/tree/master/models/bvlc_googlenet
SqueezeNet: https://github.com/DeepScale/SqueezeNet/tree/master/SqueezeNet_v1.0

